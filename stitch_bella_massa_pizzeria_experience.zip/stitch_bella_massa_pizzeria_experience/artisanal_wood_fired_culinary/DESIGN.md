---
name: Artisanal Wood-Fired Culinary
colors:
  surface: '#161311'
  surface-dim: '#161311'
  surface-bright: '#3d3836'
  surface-container-lowest: '#110d0c'
  surface-container-low: '#1f1b19'
  surface-container: '#231f1d'
  surface-container-high: '#2e2927'
  surface-container-highest: '#393431'
  on-surface: '#eae1dd'
  on-surface-variant: '#e4beba'
  inverse-surface: '#eae1dd'
  inverse-on-surface: '#342f2d'
  outline: '#ab8985'
  outline-variant: '#5b403d'
  surface-tint: '#ffb3ac'
  primary: '#ffb3ac'
  on-primary: '#680008'
  primary-container: '#d32f2f'
  on-primary-container: '#fff2f0'
  inverse-primary: '#ba1a20'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#88d982'
  on-tertiary: '#003909'
  tertiary-container: '#307f34'
  on-tertiary-container: '#d8ffd0'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#930010'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#a3f69c'
  tertiary-fixed-dim: '#88d982'
  on-tertiary-fixed: '#002204'
  on-tertiary-fixed-variant: '#005312'
  background: '#161311'
  on-background: '#eae1dd'
  surface-variant: '#393431'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system expresses the sensory depth, rustic heritage, and artisanal precision of traditional Neapolitan wood-fired pizza translated into a modern, tactile mobile ordering experience. The design direction merges **Modern Rustic Tactility** with **Warm Editorial Elegance**.

### Personality & Emotional Response
The interface evokes the warmth of a 900-degree stone oven, the rich aromas of blistered dough, and the vibrant freshness of San Marzano tomatoes and basil. The user should feel the warmth, authenticity, and confidence of stepping into a boutique pizzeria in Naples, while experiencing zero friction when customizing toppings, tracking preparation states, or executing rapid checkouts.

### Design Movements & Visual Language
- **Atmospheric Warm Contrast:** Dark, charred slate foundations accented by warm terracotta-red and melted amber, grounded with flour-dusted warm cream for high-contrast legibility.
- **Tactile Materiality:** Buttons, pill chips, and quantity selectors feel physically pressable with soft inner glows, rich dimensional drop shadows, and subtle textural surface tiers.
- **Editorial Appetite Appeal:** Editorial high-contrast serif typography commands headlines and dish names, while crisp geometric sans-serifs structure dense menu details, crust selectors, and nutritional badges.

## Colors

The palette establishes an immersive, ember-lit culinary mood using dark oven-charred neutral foundations that make food photography and ingredient badges pop with appetizing intensity.

### Palette Architecture
- **Primary (`#D32F2F` — San Marzano Red):** The focal driver for primary conversion actions: Add to Cart buttons, active state toggles, checkout CTAs, and promotional flags.
- **Secondary (`#F59E0B` — Mozzarella Amber):** Highlights wood-fired crust badges, customer ratings, loyalty rewards points, and active delivery tracking status markers.
- **Tertiary (`#2E7D32` — Fresh Basil Green):** Reserved exclusively for culinary tags such as D.O.P. certifications, vegetarian indicators, and organic ingredient authentications.
- **Neutral Core (`#1E1A18` — Charred Wood):**
  - Background Canvas: `#141211` (Deep Charcoal Hearth)
  - Card & Container Surface: `#1E1A18` (Smoked Oak)
  - Elevated Popovers & Navigation: `#2A2421` (Warm Ember Slate)
  - Low-Contrast Borders: `#3B3430` (Char Dust Outline)
- **High-Contrast Typography & Surface Accents:**
  - Primary Text / Cream White: `#FAF7F2` (Unbleached Flour)
  - Secondary Text / Warm Sand: `#C8BFB5` (Semolina Grain)
  - Muted Text / Stone Ash: `#8C827A`

## Typography

The typographic strategy pairs Italian editorial heritage with fluid mobile utility.

### Hierarchy & Usage
- **Playfair Display:** Reserved strictly for display heroes, featured pizza titles, authentic Italian naming conventions, and category headlines. It conveys high-craft culinary tradition.
- **Plus Jakarta Sans:** Drives the transactional, interactive, and structural layers. Its contemporary geometric proportions maintain crisp optical legibility on high-density mobile screens, specifically across dietary tags, calorie counters, modifiers, price points, and cart math.
- **Letter Spacing:** Headlines carry slight negative tracking (`-0.01em` to `-0.02em`) for an intentional editorial look, while utility labels and badges use positive uppercase tracking (`0.04em` to `0.06em`) to ensure legibility on small scales.

## Layout & Spacing

The layout is built for fluid mobile-first thumb interaction, maintaining safe boundaries and generous tap areas.

### Mobile Grid & Layout Principles
- **Layout Model:** Single-column fluid view for mobile handhelds (<640px) expanding into a balanced 2-column or 3-column masonry grid on tablet/desktop viewports.
- **Screen Margins:** Fixed `1rem` (16px) lateral margins on mobile ensure content utilizes the viewport width while preventing edge clipping.
- **Interactive Thumb Zone:** Primary ordering controls, sticky checkout summaries, and category horizontal scroll filters are anchored to the lower 40% of the mobile viewport.
- **Rhythm & Grouping:** Spacing between individual card elements follows `space-md` (16px), while grouped customization blocks (crust types, base sauces, cheese quantities) utilize `space-sm` (8px) interior gaps and `space-xl` (32px) section demarcations.

## Elevation & Depth

Visual hierarchy on dark surfaces relies on elevated tonal luminosity combined with warm ambient drop shadows, mimicking light emitted by oven coals.

### Surface Tiers
- **Tier 0 (Base Canvas):** `#141211` — Flat backdrop.
- **Tier 1 (Cards & Product Tiles):** `#1E1A18` bounded by a 1px border of `rgba(250, 247, 242, 0.08)`.
- **Tier 2 (Popovers, Bottom Sheets & Modals):** `#2A2421` bounded by a 1px border of `rgba(250, 247, 242, 0.12)`.
- **Tier 3 (Sticky Nav & Floating Action Bars):** `#1E1A18` with 90% opacity and a `16px` backdrop-filter blur.

### Shadow Styles
- **Soft Ambient:** `0 8px 24px -4px rgba(0, 0, 0, 0.5), 0 2px 6px -1px rgba(0, 0, 0, 0.3)` used on resting pizza product cards.
- **Warm Radiant Glow (Primary CTAs):** `0 8px 20px -2px rgba(211, 47, 47, 0.35)` applied to red primary actions to create vibrant prominence.
- **Floating Sheet Elevation:** `0 -10px 30px rgba(0, 0, 0, 0.6)` applied to the sticky mobile cart preview bar.

## Shapes

The design system uses smooth, generous corner geometry reflecting the organic, hand-stretched shapes of authentic pizza dough and fresh ingredients.

### Corner Radius Standards
- **Standard Cards & Sheet Modals (`rounded-lg` / 16px):** Primary menu cards, ingredient selection drawers, and ingredient preview containers.
- **Featured Banners & Hero Containers (`rounded-xl` / 24px):** Chef's special hero banners, pizza builder preview window, and story cards.
- **Tactile Micro-Elements (`rounded-full` / Pill):** Dietary tags, rating badges, category filter chips, search fields, and quantity stepper controls.

## Components

### Buttons
- **Primary (Action Red):** Solid `#D32F2F` fill, cream text (`#FAF7F2`), font `label-lg`, `rounded-full`, with subtle warm shadow. Height is fixed at 52px for mobile touch compliance. Active press scales down slightly (`scale-98`).
- **Secondary (Smoked Wood):** Surface `#2A2421` with a `1px` border of `rgba(250, 247, 242, 0.15)`, cream text, `rounded-full`.
- **Icon / Stepper Buttons:** Circular 36px buttons (`#2A2421`) for decrement/increment operations with haptic-ready high-contrast glyphs.

### Chips & Dietary Tags
- **Dietary Badges:** Pill-shaped tags (`rounded-full`, padding `4px 10px`, typography `label-sm`).
  - *D.O.P. / Authentic:* Rich amber background (`rgba(245, 158, 11, 0.15)`), amber text (`#F59E0B`), border `1px solid rgba(245, 158, 11, 0.3)`.
  - *Vegetarian / Bio:* Basil green background (`rgba(46, 125, 50, 0.15)`), green text (`#4CAF50`), border `1px solid rgba(76, 175, 80, 0.3)`.
  - *Picante (Spicy):* Red tint (`rgba(211, 47, 47, 0.15)`), red text (`#EF5350`), accompanied by a flame micro-icon.
- **Category Filter Chips:** Horizontal scrolling pills. Active chip features San Marzano Red background with cream text; inactive chips feature charcoal background (`#1E1A18`) with sand text (`#C8BFB5`).

### Product Cards
- **Orientation:** Dual format (horizontal list item for rapid re-orders; full-width vertical card with top bleed photography for signature pizzas).
- **Styling:** Tier 1 background (`#1E1A18`), soft ambient shadow, 16px radius. Displays high-contrast title in Playfair Display, ingredient lists in muted sans-serif, price anchored bottom-left, and quick-add action bottom-right.

### Quantity Stepper
- Seamless integrated pill component with charcoal background (`#2A2421`), crisp cream digits in `headline-sm`, and tactile plus/minus triggers on opposite edges to prevent accidental double-taps.

### Input Fields & Modifiers
- Inset dark input wells (`#141211`) with border transitions from charcoal to San Marzano Red on focus. Checkboxes and radio buttons for crust and topping add-ons feature circular pill selection rings with warm amber active states.

### Sticky Mobile Navigation & Cart Counter
- Fixed bottom dock featuring a frosted smoked-glass backdrop (`#1E1A18` at 90% opacity, 16px blur) with ergonomic tap targets.
- Cart pill displays real-time item count in a San Marzano Red badge, item total in bold cream, and right-aligned arrow checkout trigger.